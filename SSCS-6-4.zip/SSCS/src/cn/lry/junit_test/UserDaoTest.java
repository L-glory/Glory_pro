package cn.lry.junit_test;

import org.junit.Test;

import cn.lry.dao.UserDao;
import cn.lry.dao.factory.UserDaoFactory;
import cn.lry.domains.Person;
import cn.lry.domains.Student;

public class UserDaoTest {

	@Test
	public void add(){
		Person p1 = new Person(20134654,"����ҫ");
		Student s1 = new Student("��","2013-9-1","��������","����ѧԺ",1302);
		
		p1.setStu(s1);
		
		UserDao userdao = UserDaoFactory.getInstance();
		userdao.add(p1);
		
	}
	
};
