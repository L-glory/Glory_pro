package cn.lry.domains;

import java.util.Set;

public class Student extends Person {

	//ѧ��
	private int stuId;
	//�Ա�
	private String stuSex;
	//��ѧʱ��
	private String stuDim;
	//רҵ
	private String stuMajor;
	//ѧԺ
	private String stuCollege;
	//�༶
	private int stuClass;
	//�û�
	private Person person;
	//��ѡ�μ���
	private Set<Course> courses;
	
	/**
	 * @function    �޲ι���
	 */
	public Student() {
		super();
		//this.courses = new HashSet<Course>();
	}
	
	/**
	 * @function    ���췽��
	 * @param stuId
	 * @param stuSex
	 * @param stuDim
	 * @param stuMajor
	 * @param stuCollege
	 * @param stuClass
	 */
	public Student(String stuSex, 
				    String stuDim, String stuMajor, 
					String stuCollege, int stuClass) {
		this.stuSex = stuSex;
		this.stuDim = stuDim;
		this.stuMajor = stuMajor;
		this.stuCollege = stuCollege;
		this.stuClass = stuClass;
	}
	
	public int getStuId() {
		return stuId;
	}

	public void setStuId(int stuId) {
		this.stuId = stuId;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public String getStuSex() {
		return stuSex;
	}
	public void setStuSex(String stuSex) {
		this.stuSex = stuSex;
	}
	public String getStuDim() {
		return stuDim;
	}
	public void setStuDim(String stuDim) {
		this.stuDim = stuDim;
	}
	public String getStuMajor() {
		return stuMajor;
	}
	public void setStuMajor(String stuMajor) {
		this.stuMajor = stuMajor;
	}
	public String getStuCollege() {
		return stuCollege;
	}
	public void setStuCollege(String stuCollege) {
		this.stuCollege = stuCollege;
	}
	public int getStuClass() {
		return stuClass;
	}
	public void setStuClass(int stuClass) {
		this.stuClass = stuClass;
	}
	public Set<Course> getCourses() {
		return courses;
	}
	public void setCourses(Set<Course> cours) {
		this.courses = cours;
	}

	@Override
	public String toString() {
		return "Student [stuId=" + stuId + ", stuSex=" + stuSex + ", stuDim="
				+ stuDim + ", stuMajor=" + stuMajor + ", stuCollege="
				+ stuCollege + ", stuClass=" + stuClass + ", person=" + person
				+ "]";
	}
};
