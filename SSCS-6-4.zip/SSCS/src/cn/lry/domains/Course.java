package cn.lry.domains;

import java.util.Set;

public class Course {
	
	//�γ̱��
	private int id;
	//�γ�����
	private String name;
	//�Ͽ���ʦ
	private String cTeachName;
	//�γ�����
	private String cType;
	//�Ͽεص�
	private String cPlace;
	//ѧʱ
	private int cHours;
	//ѧ��
	private int cCredit;
	//ѡ��ѧ������
	private Set<Student> stus;
	
	/**
	 * �޲ι���
	 */
	public Course() {
		super();
		//this.stus = new HashSet<Student>();
	}
	
	/**
	 * @function    ���췽��
	 * @param id
	 * @param name
	 * @param teachName
	 * @param cType
	 * @param cPlace
	 * @param cHours
	 * @param cCredit
	 */
	public Course(int id, String name, String cTeachName, 
			       String cType, String cPlace, int cHours,
			       int cCredit) {
		super();
		this.id = id;
		this.name = name;
		this.cTeachName = cTeachName;
		this.cType = cType;
		this.cPlace = cPlace;
		this.cHours = cHours;
		this.cCredit = cCredit;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCTeachName() {
		return cTeachName;
	}

	public void setCTeachName(String teachName) {
		this.cTeachName = teachName;
	}

	public String getcType() {
		return cType;
	}

	public void setcType(String cType) {
		this.cType = cType;
	}

	public String getcPlace() {
		return cPlace;
	}

	public void setcPlace(String cPlace) {
		this.cPlace = cPlace;
	}

	public int getcHours() {
		return cHours;
	}

	public void setcHours(int cHours) {
		this.cHours = cHours;
	}

	public int getcCredit() {
		return cCredit;
	}

	public void setcCredit(int cCredit) {
		this.cCredit = cCredit;
	}

	public Set<Student> getStus() {
		return stus;
	}

	public void setStus(Set<Student> stus) {
		this.stus = stus;
	}
	
	public void setStus(Student stu){
		this.stus.add(stu);
	}

	@Override
	public String toString() {
		return "Course [id=" + id + ", name=" + name + ", cTeachName="
				+ cTeachName + ", cType=" + cType + ", cPlace=" + cPlace
				+ ", cHours=" + cHours + ", cCredit=" + cCredit + "]";
	}
};
