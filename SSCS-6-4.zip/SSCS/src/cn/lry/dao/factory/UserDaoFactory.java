package cn.lry.dao.factory;

import cn.lry.dao.UserDao;
import cn.lry.dao.impl.UserDaoImpl;

public class UserDaoFactory {
	
	private static UserDao userdao = null;
	private UserDaoFactory(){}
	
	public static UserDao getInstance(){
		if(userdao == null){
			userdao = new UserDaoImpl();
		}
		return userdao;
	}
};
