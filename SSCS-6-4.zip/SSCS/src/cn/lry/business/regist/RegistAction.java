package cn.lry.business.regist;

import com.opensymphony.xwork2.ActionSupport;

public class RegistAction extends ActionSupport {

	private static final long serialVersionUID = -1427594388916285635L;

	private int id;
	private String pwd;
	private String name;
}
